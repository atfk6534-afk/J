import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/student_model.dart';
import '../models/attendance_model.dart';
import '../models/visit_model.dart';
import '../models/assignment_model.dart';
import '../models/trip_booking_model.dart';
import '../models/trip_model.dart';
import 'local_db_service.dart';
import 'firestore_service.dart';
import 'connectivity_service.dart';

/// ─────────────────────────────────────────────────────────────────────────────
/// SyncService — Firestore هي المصدر الوحيد للحقيقة
///
/// القواعد الصارمة:
///   • لا تُرفع بيانات محلية قبل اكتمال السحب الأولي
///   • لا تُمسح بيانات Firestore بسبب قاعدة بيانات محلية فارغة
///   • كل عملية حذف تحتاج إجراء صريح من المستخدم
///   • المزامنة لا تبدأ إلا بعد تسجيل الدخول (auth != null)
/// ─────────────────────────────────────────────────────────────────────────────
class SyncService {
  final LocalDbService      _local;
  final FirestoreService    _remote;
  final ConnectivityService _connectivity;

  StreamSubscription? _studentsSub;
  StreamSubscription? _attendanceSub;
  StreamSubscription? _visitsSub;
  StreamSubscription<bool>? _connectivitySub;

  bool _initialSyncDone = false;
  bool _isSyncing       = false;

  final _onDataChanged = StreamController<void>.broadcast();
  Stream<void> get onDataChanged => _onDataChanged.stream;

  SyncService(this._local, this._remote, this._connectivity);

  // ───────────────────────────────────────────────────────────────────────────
  // performInitialSync
  //   • يُستدعى مباشرة بعد تسجيل الدخول الناجح
  //   • يُرجع Future يكتمل بعد انتهاء التحميل الكامل
  //   • يعرض شاشة التحميل حتى يكتمل
  // ───────────────────────────────────────────────────────────────────────────
  Future<void> performInitialSync() async {
    if (FirebaseAuth.instance.currentUser == null) return;
    if (!await _connectivity.isOnline()) {
      _initialSyncDone = true;
      return;
    }

    try {
      await _downloadAllFromFirestore();
      await _pushPendingChanges(); // ارفع المعلق المحلي (لو كان)
    } catch (_) {
      // فشل التحميل → التطبيق يشتغل بالداتا المحلية الموجودة
    }

    _initialSyncDone = true;
    _startRealtimeListeners();
    _watchConnectivity();
  }

  // ───────────────────────────────────────────────────────────────────────────
  // _downloadAllFromFirestore
  //   • يجلب كل شيء من Firestore ويحفظه محليًا
  //   • لا يمسح أي بيانات موجودة محليًا
  //   • يطبّق Last-Write-Wins فقط للتحديث (مش للحذف)
  // ───────────────────────────────────────────────────────────────────────────
  Future<void> _downloadAllFromFirestore() async {
    if (FirebaseAuth.instance.currentUser == null) return;

    bool changed = false;

    // ── الشباب ──────────────────────────────────────────────────────────────
    final remoteStudents = await _remote.fetchAllStudents();
    for (final r in remoteStudents) {
      final local = _local.getStudent(r.id);
      if (local == null) {
        // جديد على الجهاز → احفظه
        await _local.saveStudent(r.copyWith(needsSync: false));
        changed = true;
      } else if (!local.needsSync && r.updatedAt.isAfter(local.updatedAt)) {
        // Firestore أحدث → حدّث المحلي
        await _local.saveStudent(r.copyWith(needsSync: false));
        changed = true;
      }
      // لو local.needsSync = true → المحلي أحدث → لا تكتب فوقه
    }

    // ── الحضور ──────────────────────────────────────────────────────────────
    final remoteAtt = await _remote.fetchAllAttendance();
    for (final r in remoteAtt) {
      final localList = _local.getAttendanceForStudent(r.studentId);
      final local     = localList.where((l) => l.id == r.id).firstOrNull;
      if (local == null) {
        await _local.saveAttendanceRecord(r.copyWith(needsSync: false));
        changed = true;
      } else if (!local.needsSync && r.updatedAt.isAfter(local.updatedAt)) {
        await _local.saveAttendanceRecord(r.copyWith(needsSync: false));
        changed = true;
      }
    }

    // ── الافتقاد ─────────────────────────────────────────────────────────────
    final remoteVisits = await _remote.fetchAllVisits();
    for (final r in remoteVisits) {
      final local = _local.getVisit(r.id);
      if (local == null) {
        await _local.saveVisit(r.copyWith(needsSync: false));
        changed = true;
      } else if (!local.needsSync && r.updatedAt.isAfter(local.updatedAt)) {
        await _local.saveVisit(r.copyWith(needsSync: false));
        changed = true;
      }
    }

    if (changed) _onDataChanged.add(null);
  }

  // ───────────────────────────────────────────────────────────────────────────
  // _pushPendingChanges — رفع التغييرات المحلية المعلقة فقط
  //   • لا يُرفع أي شيء لو Firestore فيه بيانات أكتر من المحلي
  //     (علامة على إن المحلي ناقص وليس مصدر الحقيقة)
  // ───────────────────────────────────────────────────────────────────────────
  Future<void> _pushPendingChanges() async {
    if (FirebaseAuth.instance.currentUser == null) return;
    if (!await _connectivity.isOnline()) return;

    // لا ترفع لو المحلي فاضٍ تمامًا (خطر رفع بيانات ناقصة فوق Firestore)
    final localStudents = _local.getAllStudents(includeDeleted: true);
    if (localStudents.isEmpty) return;

    await _pushPendingStudents();
    await _pushPendingAttendance();
    await _pushPendingVisits();
    await _pushPendingTrips();
    await _pushPendingBookings();
    await _pushPendingAssignments();
  }

  Future<void> _pushPendingStudents() async {
    for (final s in _local.getStudentsNeedingSync()) {
      try {
        await _remote.pushStudent(s);
        await _local.saveStudent(s.copyWith(needsSync: false));
      } catch (_) {}
    }
  }

  Future<void> _pushPendingAttendance() async {
    final pending = _local.getAttendanceNeedingSync();
    if (pending.isEmpty) return;
    try {
      await _remote.pushAttendanceBatch(pending);
      await _local.saveAttendanceBatch(
          pending.map((r) => r.copyWith(needsSync: false)).toList());
    } catch (_) {}
  }

  Future<void> _pushPendingVisits() async {
    final pending = _local.getVisitsNeedingSync();
    if (pending.isEmpty) return;
    try {
      await _remote.pushVisitBatch(pending);
      for (final v in pending) {
        await _local.saveVisit(v.copyWith(needsSync: false));
      }
    } catch (_) {}
  }

  // ───────────────────────────────────────────────────────────────────────────
  // syncNow — يُستدعى بعد أي إضافة أو تعديل محلي
  // ───────────────────────────────────────────────────────────────────────────
  Future<void> syncNow() async {
    if (!_initialSyncDone) return; // لا ترفع قبل اكتمال التحميل
    if (FirebaseAuth.instance.currentUser == null) return;
    if (_isSyncing) return;
    _isSyncing = true;
    try {
      if (!await _connectivity.isOnline()) return;
      await _pushPendingStudents();
      await _pushPendingAttendance();
      await _pushPendingVisits();
    } finally {
      _isSyncing = false;
    }
  }

  // ───────────────────────────────────────────────────────────────────────────
  // الاستماع اللحظي والاتصال
  // ───────────────────────────────────────────────────────────────────────────
  void _startRealtimeListeners() {
    _cancelListeners();
    _studentsSub  = _remote.watchStudents().listen(_mergeRemoteStudents);
    _attendanceSub = _remote.watchAttendance().listen(_mergeRemoteAttendance);
    _visitsSub    = _remote.watchVisits().listen(_mergeRemoteVisits);
  }

  void _watchConnectivity() {
    _connectivitySub?.cancel();
    _connectivitySub = _connectivity.onStatusChange.listen((online) async {
      if (online && _initialSyncDone) {
        await _pushPendingChanges();
        _startRealtimeListeners();
      } else if (!online) {
        _cancelListeners();
      }
    });
  }

  void _cancelListeners() {
    _studentsSub?.cancel();
    _attendanceSub?.cancel();
    _visitsSub?.cancel();
  }

  // ───────────────────────────────────────────────────────────────────────────
  // دمج البيانات الواردة من Real-time listeners
  //   • أضف فقط أو حدّث إذا كان Firestore أحدث
  //   • لا تحذف أي بيانات محلية
  // ───────────────────────────────────────────────────────────────────────────
  void _mergeRemoteStudents(List<StudentModel> remotes) async {
    if (!_initialSyncDone) return;
    bool changed = false;
    for (final r in remotes) {
      final local = _local.getStudent(r.id);
      if (local == null) {
        await _local.saveStudent(r.copyWith(needsSync: false));
        changed = true;
      } else if (!local.needsSync && r.updatedAt.isAfter(local.updatedAt)) {
        await _local.saveStudent(r.copyWith(needsSync: false));
        changed = true;
      }
    }
    if (changed) _onDataChanged.add(null);
  }

  void _mergeRemoteAttendance(List<AttendanceRecord> remotes) async {
    if (!_initialSyncDone) return;
    bool changed = false;
    for (final r in remotes) {
      final localList = _local.getAttendanceForStudent(r.studentId);
      final local     = localList.where((l) => l.id == r.id).firstOrNull;
      if (local == null) {
        await _local.saveAttendanceRecord(r.copyWith(needsSync: false));
        changed = true;
      } else if (!local.needsSync && r.updatedAt.isAfter(local.updatedAt)) {
        await _local.saveAttendanceRecord(r.copyWith(needsSync: false));
        changed = true;
      }
    }
    if (changed) _onDataChanged.add(null);
  }

  void _mergeRemoteVisits(List<VisitRecord> remotes) async {
    if (!_initialSyncDone) return;
    bool changed = false;
    for (final r in remotes) {
      final local = _local.getVisit(r.id);
      if (local == null) {
        await _local.saveVisit(r.copyWith(needsSync: false));
        changed = true;
      } else if (!local.needsSync && r.updatedAt.isAfter(local.updatedAt)) {
        await _local.saveVisit(r.copyWith(needsSync: false));
        changed = true;
      }
    }
    if (changed) _onDataChanged.add(null);
  }

  void stopListeners() {
    _cancelListeners();
    _connectivitySub?.cancel();
    _initialSyncDone = false;
  }

  void dispose() {
    stopListeners();
    _onDataChanged.close();
  }
}
