import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/assignment_model.dart';
import '../core/utils/date_helper.dart';
import 'local_db_service.dart';

/// خدمة الإشعارات المحلية — تُذكّر الخادم بالكلمة أو اللحن
class NotificationService {
  static final NotificationService _i = NotificationService._();
  factory NotificationService() => _i;
  NotificationService._();

  final _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(
      const InitializationSettings(android: android),
    );
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
    _initialized = true;
  }

  /// عرض إشعار فوري
  Future<void> showImmediate({
    required String title,
    required String body,
    required int id,
  }) async {
    await init();
    await _plugin.show(
      id,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'assignments_channel',
          'توزيع الكلمة واللحن',
          channelDescription: 'تذكيرات توزيع الكلمة واللحن',
          importance: Importance.high,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
        ),
      ),
    );
  }

  /// إرسال واتساب تذكير لصاحب التوزيع
  Future<bool> sendWhatsappReminder(AssignmentModel a) async {
    if (a.assignedToPhone.isEmpty) return false;
    final lessonDate = DateHelper.fromKey(a.dateKey);
    final msg = 'السلام عليكم يا ${a.assignedTo} 🙏\n'
        'تذكير: لديك ${a.type} في حصة يوم '
        '${DateHelper.displayDateWithDay(lessonDate)}\n'
        '${a.notes.isNotEmpty ? 'ملاحظة: ${a.notes}\n' : ''}'
        'بالتوفيق 🌟';
    final encoded = Uri.encodeComponent(msg);
    final phone = a.assignedToPhone.replaceAll(RegExp(r'[^0-9]'), '');
    final url = Uri.parse('https://wa.me/2$phone?text=$encoded');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
      return true;
    }
    return false;
  }

  /// فحص التوزيعات التي حان وقت تذكيرها وإرسال إشعار
  Future<void> checkPendingNotifications(LocalDbService local) async {
    await init();
    final pending = local.getPendingNotifications();
    for (final a in pending) {
      final lessonDate = DateHelper.fromKey(a.dateKey);
      await showImmediate(
        id: a.id.hashCode.abs(),
        title: '📋 تذكير: ${a.type}',
        body: 'يا ${a.assignedTo}، لديك ${a.type} يوم '
            '${DateHelper.displayDateWithDay(lessonDate)}'
            '${a.notes.isNotEmpty ? ' — ${a.notes}' : ''}',
      );
      await local.saveAssignment(
          a.copyWith(notificationSent: true, needsSync: true));
    }
  }

  Future<void> cancelAll() => _plugin.cancelAll();
}
