import 'package:hive_flutter/hive_flutter.dart';
import '../core/constants/app_constants.dart';
import '../core/utils/date_helper.dart';
import '../models/student_model.dart';
import '../models/attendance_model.dart';
import '../models/visit_model.dart';
import '../models/point_adjustment_model.dart';
import '../models/trip_model.dart';
import '../models/trip_booking_model.dart';
import '../models/assignment_model.dart';

class LocalDbService {
  static final LocalDbService _i = LocalDbService._();
  factory LocalDbService() => _i;
  LocalDbService._();

  late Box<StudentModel>       _studentsBox;
  late Box<AttendanceRecord>   _attendanceBox;
  late Box<VisitRecord>        _visitsBox;
  late Box<PointAdjustment>    _pointsBox;
  late Box<TripModel>          _tripsBox;
  late Box<TripBooking>        _bookingsBox;
  late Box<AssignmentModel>    _assignmentsBox;

  Future<void> init() async {
    await Hive.initFlutter();
    if (!Hive.isAdapterRegistered(0)) Hive.registerAdapter(StudentModelAdapter());
    if (!Hive.isAdapterRegistered(1)) Hive.registerAdapter(AttendanceRecordAdapter());
    if (!Hive.isAdapterRegistered(2)) Hive.registerAdapter(VisitRecordAdapter());
    if (!Hive.isAdapterRegistered(3)) Hive.registerAdapter(PointAdjustmentAdapter());
    if (!Hive.isAdapterRegistered(4)) Hive.registerAdapter(TripModelAdapter());
    if (!Hive.isAdapterRegistered(5)) Hive.registerAdapter(TripBookingAdapter());
    if (!Hive.isAdapterRegistered(6)) Hive.registerAdapter(AssignmentModelAdapter());

    _studentsBox    = await Hive.openBox<StudentModel>     (AppConstants.studentsBox);
    _attendanceBox  = await Hive.openBox<AttendanceRecord> (AppConstants.attendanceBox);
    _visitsBox      = await Hive.openBox<VisitRecord>      (AppConstants.visitsBox);
    _pointsBox      = await Hive.openBox<PointAdjustment>  ('points_box');
    _tripsBox       = await Hive.openBox<TripModel>        ('trips_box');
    _bookingsBox    = await Hive.openBox<TripBooking>      ('bookings_box');
    _assignmentsBox = await Hive.openBox<AssignmentModel>  ('assignments_box');
  }

  // ════════ الشباب ════════════════════════════════════════════════════════════
  List<StudentModel> getAllStudents({bool includeDeleted = false}) {
    final l = _studentsBox.values.toList();
    final f = includeDeleted ? l : l.where((s) => !s.isDeleted).toList();
    f.sort((a, b) => a.firstName.compareTo(b.firstName));
    return f;
  }
  StudentModel? getStudent(String id) => _studentsBox.get(id);
  Future<void> saveStudent(StudentModel s) => _studentsBox.put(s.id, s);
  Future<void> softDeleteStudent(String id) async {
    final s = _studentsBox.get(id);
    if (s != null) await _studentsBox.put(id, s.copyWith(isDeleted: true, updatedAt: DateTime.now(), needsSync: true));
  }
  Future<void> hardDeleteStudent(String id) async {
    final s = _studentsBox.get(id);
    if (s != null) {
      await _studentsBox.put(id, s.copyWith(isDeleted: true, permanentlyDeleted: true, updatedAt: DateTime.now(), needsSync: true));
    }
  }
  List<StudentModel> getStudentsNeedingSync() => _studentsBox.values.where((s) => s.needsSync).toList();

  // ════════ الحضور ════════════════════════════════════════════════════════════
  List<AttendanceRecord> getAttendanceForDate(String dateKey) =>
      _attendanceBox.values.where((a) => a.dateKey == dateKey && !a.isDeleted).toList();
  List<AttendanceRecord> getAttendanceForActivity(String dateKey, String activity) =>
      _attendanceBox.values.where((a) => a.dateKey == dateKey && a.activity == activity && !a.isDeleted).toList();
  List<AttendanceRecord> getAttendanceForStudent(String studentId) {
    final l = _attendanceBox.values.where((a) => a.studentId == studentId && !a.isDeleted).toList();
    l.sort((a, b) => b.dateKey.compareTo(a.dateKey));
    return l;
  }
  List<AttendanceRecord> getAllAttendance({bool includeDeleted = false}) {
    final l = _attendanceBox.values.toList();
    return includeDeleted ? l : l.where((a) => !a.isDeleted).toList();
  }
  Future<void> saveAttendanceRecord(AttendanceRecord r) => _attendanceBox.put(r.id, r);
  Future<void> saveAttendanceBatch(List<AttendanceRecord> records) =>
      _attendanceBox.putAll({for (final r in records) r.id: r});
  Future<void> hardDeleteAllAttendance() async {
    final all = _attendanceBox.values.toList();
    for (final a in all) {
      await _attendanceBox.put(a.id, a.copyWith(isDeleted: true, permanentlyDeleted: true, updatedAt: DateTime.now(), needsSync: true));
    }
  }
  List<AttendanceRecord> getAttendanceNeedingSync() => _attendanceBox.values.where((a) => a.needsSync).toList();
  String? getLastRecordedDateKey() {
    final keys = _attendanceBox.values.map((a) => a.dateKey).toSet().toList();
    if (keys.isEmpty) return null;
    keys.sort();
    return keys.last;
  }

  // ════════ الافتقاد ══════════════════════════════════════════════════════════
  List<VisitRecord> getVisitsForStudent(String studentId) {
    final l = _visitsBox.values.where((v) => v.studentId == studentId && !v.isDeleted).toList();
    l.sort((a, b) => b.dateKey.compareTo(a.dateKey));
    return l;
  }
  List<VisitRecord> getAllVisits({bool includeDeleted = false}) {
    final l = _visitsBox.values.toList();
    return includeDeleted ? l : l.where((v) => !v.isDeleted).toList();
  }
  VisitRecord? getVisit(String id) => _visitsBox.get(id);
  Future<void> saveVisit(VisitRecord v) => _visitsBox.put(v.id, v);
  Future<void> hardDeleteAllVisits() async {
    final all = _visitsBox.values.toList();
    for (final v in all) {
      await _visitsBox.put(v.id, v.copyWith(isDeleted: true, permanentlyDeleted: true, updatedAt: DateTime.now(), needsSync: true));
    }
  }
  List<VisitRecord> getVisitsNeedingSync() => _visitsBox.values.where((v) => v.needsSync).toList();

  // ════════ النقاط ════════════════════════════════════════════════════════════
  List<PointAdjustment> getAdjustmentsForStudent(String studentId) =>
      _pointsBox.values.where((a) => a.studentId == studentId && !a.isDeleted).toList();
  List<PointAdjustment> getAllAdjustments() =>
      _pointsBox.values.where((a) => !a.isDeleted).toList();
  Future<void> saveAdjustment(PointAdjustment a) => _pointsBox.put(a.id, a);
  Future<void> hardDeleteAllAdjustments() async {
    final all = _pointsBox.values.toList();
    for (final a in all) {
      await _pointsBox.put(a.id, a.copyWith(isDeleted: true, permanentlyDeleted: true, updatedAt: DateTime.now(), needsSync: true));
    }
  }
  List<PointAdjustment> getAdjustmentsNeedingSync() => _pointsBox.values.where((a) => a.needsSync).toList();

  // ════════ الرحلات ═══════════════════════════════════════════════════════════
  List<TripModel> getAllTrips({bool includeDeleted = false}) {
    final l = _tripsBox.values.toList();
    final f = includeDeleted ? l : l.where((t) => !t.isDeleted).toList();
    f.sort((a, b) => b.dateKey.compareTo(a.dateKey));
    return f;
  }
  TripModel? getTrip(String id) => _tripsBox.get(id);
  Future<void> saveTrip(TripModel t) => _tripsBox.put(t.id, t);
  Future<void> hardDeleteTrip(String id) async {
    final t = _tripsBox.get(id);
    if (t != null) await _tripsBox.put(id, t.copyWith(isDeleted: true, permanentlyDeleted: true, updatedAt: DateTime.now(), needsSync: true));
  }
  List<TripModel> getTripsNeedingSync() => _tripsBox.values.where((t) => t.needsSync).toList();

  // ════════ حجوزات الرحلات ════════════════════════════════════════════════════
  List<TripBooking> getBookingsForTrip(String tripId) =>
      _bookingsBox.values.where((b) => b.tripId == tripId && !b.isDeleted).toList();
  List<TripBooking> getBookingsForStudent(String studentId) =>
      _bookingsBox.values.where((b) => b.studentId == studentId && !b.isDeleted).toList();
  TripBooking? getBooking(String id) => _bookingsBox.get(id);
  Future<void> saveBooking(TripBooking b) => _bookingsBox.put(b.id, b);
  Future<void> hardDeleteBooking(String id) async {
    final b = _bookingsBox.get(id);
    if (b != null) await _bookingsBox.put(id, b.copyWith(isDeleted: true, permanentlyDeleted: true, updatedAt: DateTime.now(), needsSync: true));
  }
  List<TripBooking> getBookingsNeedingSync() => _bookingsBox.values.where((b) => b.needsSync).toList();

  // ════════ التوزيعات ══════════════════════════════════════════════════════════
  List<AssignmentModel> getAllAssignments({bool includeDeleted = false}) {
    final l = _assignmentsBox.values.toList();
    final f = includeDeleted ? l : l.where((a) => !a.isDeleted).toList();
    f.sort((a, b) => b.dateKey.compareTo(a.dateKey));
    return f;
  }
  List<AssignmentModel> getUpcomingAssignments() {
    final today = DateHelper.dateKey(DateTime.now());
    return _assignmentsBox.values.where((a) => !a.isDeleted && a.dateKey >= today).toList()
      ..sort((a, b) => a.dateKey.compareTo(b.dateKey));
  }
  AssignmentModel? getAssignment(String id) => _assignmentsBox.get(id);
  Future<void> saveAssignment(AssignmentModel a) => _assignmentsBox.put(a.id, a);
  Future<void> hardDeleteAssignment(String id) async {
    final a = _assignmentsBox.get(id);
    if (a != null) await _assignmentsBox.put(id, a.copyWith(isDeleted: true, permanentlyDeleted: true, updatedAt: DateTime.now(), needsSync: true));
  }
  List<AssignmentModel> getAssignmentsNeedingSync() => _assignmentsBox.values.where((a) => a.needsSync).toList();
  List<AssignmentModel> getPendingNotifications() {
    final now = DateTime.now();
    return _assignmentsBox.values.where((a) {
      if (a.isDeleted || a.notificationSent) return false;
      final lessonDate = DateHelper.fromKey(a.dateKey);
      final notifyAt = lessonDate.subtract(Duration(hours: a.notifyBeforeHours));
      return now.isAfter(notifyAt);
    }).toList();
  }
}
