import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/trip_provider.dart';
import '../../providers/student_provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/date_helper.dart';
import 'trip_details_screen.dart';
import 'add_edit_trip_screen.dart';

class TripsScreen extends StatelessWidget {
  const TripsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final trips    = context.watch<TripProvider>().allTrips;

    return Scaffold(
      appBar: AppBar(
        title: const Text('الرحلات'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_rounded),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const AddEditTripScreen())),
          ),
        ],
      ),
      body: trips.isEmpty
          ? const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.directions_bus_outlined, size: 64, color: AppColors.textSecondary),
                  SizedBox(height: 12),
                  Text('لا توجد رحلات بعد'),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: trips.length,
              itemBuilder: (context, i) {
                final trip      = trips[i];
                final tripProv  = context.read<TripProvider>();
                final bookings  = tripProv.bookingsFor(trip.id);
                final paid      = tripProv.totalPaidFor(trip.id);
                final remaining = (trip.price * bookings.length) - paid;

                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppColors.primary.withValues(alpha: 0.12),
                      child: const Icon(Icons.directions_bus_rounded, color: AppColors.primary),
                    ),
                    title: Text(trip.title,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(DateHelper.displayDateWithDay(DateHelper.fromKey(trip.dateKey))),
                        Text(
                          'السعر: ${trip.price.toStringAsFixed(0)} ج • '
                          'المحجوزين: ${bookings.length}'
                          '${remaining > 0 ? ' • متبقي: ${remaining.toStringAsFixed(0)} ج' : ''}',
                          style: const TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                    trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => TripDetailsScreen(tripId: trip.id)),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
