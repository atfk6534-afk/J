import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/trip_provider.dart';
import '../../providers/student_provider.dart';
import '../../providers/auth_provider.dart';
import '../../models/trip_booking_model.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/date_helper.dart';
import 'add_edit_trip_screen.dart';

class TripDetailsScreen extends StatelessWidget {
  final String tripId;
  const TripDetailsScreen({super.key, required this.tripId});

  @override
  Widget build(BuildContext context) {
    final tripProv  = context.watch<TripProvider>();
    final studProv  = context.watch<StudentProvider>();
    final trip      = tripProv.allTrips.where((t) => t.id == tripId).firstOrNull;
    if (trip == null) return const Scaffold(body: Center(child: Text('الرحلة غير موجودة')));

    final bookings  = tripProv.bookingsFor(tripId);
    final paid      = tripProv.totalPaidFor(tripId);
    final total     = trip.price * bookings.length;
    final remaining = total - paid;

    // اسم المخدوم من الـ id
    String studentName(String id) =>
        studProv.getById(id)?.fullName ?? 'غير معروف';

    return Scaffold(
      appBar: AppBar(
        title: Text(trip.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_rounded),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => AddEditTripScreen(trip: trip))),
          ),
          IconButton(
            icon: const Icon(Icons.delete_forever_rounded, color: Colors.redAccent),
            onPressed: () => _confirmDelete(context, tripProv),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ── تفاصيل الرحلة ─────────────────────────────────────────────────
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.calendar_today_rounded, size: 16, color: AppColors.primary),
                    const SizedBox(width: 8),
                    Text(DateHelper.displayDateWithDay(DateHelper.fromKey(trip.dateKey))),
                  ]),
                  const SizedBox(height: 8),
                  Row(children: [
                    const Icon(Icons.attach_money_rounded, size: 16, color: AppColors.primary),
                    const SizedBox(width: 8),
                    Text('السعر: ${trip.price.toStringAsFixed(0)} جنيه'),
                  ]),
                  if (trip.description.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(trip.description, style: TextStyle(color: AppColors.textSecondary)),
                  ],
                  const Divider(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _stat('المحجوزين', '${bookings.length}', AppColors.primary),
                      _stat('المدفوع', '${paid.toStringAsFixed(0)} ج', AppColors.present),
                      _stat('المتبقي', '${remaining.toStringAsFixed(0)} ج',
                          remaining > 0 ? AppColors.absent : AppColors.present),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('الحجوزات',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ElevatedButton.icon(
                icon: const Icon(Icons.person_add_rounded, size: 18),
                label: const Text('إضافة حجز'),
                onPressed: () => _addBookingDialog(context, trip.price, studProv.allStudents, tripProv),
              ),
            ],
          ),
          const SizedBox(height: 8),

          if (bookings.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Center(child: Text('لا توجد حجوزات بعد')),
            )
          else
            ...bookings.map((b) {
              final name     = studentName(b.studentId);
              final leftover = trip.price - b.amountPaid;
              return Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: leftover <= 0
                        ? AppColors.present.withValues(alpha: 0.15)
                        : AppColors.warning.withValues(alpha: 0.15),
                    child: Icon(
                      leftover <= 0 ? Icons.check_circle : Icons.pending_rounded,
                      color: leftover <= 0 ? AppColors.present : AppColors.warning,
                    ),
                  ),
                  title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(
                    'دفع: ${b.amountPaid.toStringAsFixed(0)} ج'
                    '${leftover > 0 ? ' • متبقي: ${leftover.toStringAsFixed(0)} ج' : ' ✓ مسدّد'}',
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit_rounded, size: 18),
                        onPressed: () => _editBookingDialog(context, b, trip.price, tripProv),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_forever_rounded,
                            size: 18, color: AppColors.absent),
                        onPressed: () => _confirmDeleteBooking(context, b.id, name, tripProv),
                      ),
                    ],
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }

  Widget _stat(String label, String value, Color color) => Column(
    children: [
      Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color)),
      Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
    ],
  );

  Future<void> _addBookingDialog(BuildContext context, double tripPrice,
      List students, TripProvider prov) async {
    String? selectedId;
    final paidCtrl  = TextEditingController(text: tripPrice.toStringAsFixed(0));
    final notesCtrl = TextEditingController();
    final auth      = context.read<AuthProvider>();

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) => AlertDialog(
          title: const Text('إضافة حجز'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: selectedId,
                  hint: const Text('اختر الشاب'),
                  items: students.map<DropdownMenuItem<String>>((s) =>
                      DropdownMenuItem(value: s.id, child: Text(s.fullName))).toList(),
                  onChanged: (v) => setSt(() => selectedId = v),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: paidCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'المبلغ المدفوع (ج)'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: notesCtrl,
                  decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: selectedId == null ? null : () async {
                await prov.addBooking(
                  tripId: tripId, studentId: selectedId!,
                  amountPaid: double.tryParse(paidCtrl.text.trim()) ?? 0,
                  notes: notesCtrl.text.trim(),
                  createdBy: auth.currentUser?.name ?? '',
                );
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('حجز'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _editBookingDialog(BuildContext context, TripBooking b,
      double tripPrice, TripProvider prov) async {
    final paidCtrl  = TextEditingController(text: b.amountPaid.toStringAsFixed(0));
    final notesCtrl = TextEditingController(text: b.notes);
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تعديل الحجز'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: paidCtrl, keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'المبلغ المدفوع (ج)')),
            const SizedBox(height: 12),
            TextField(controller: notesCtrl,
                decoration: const InputDecoration(labelText: 'ملاحظة')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () async {
              await prov.updateBooking(b.copyWith(
                amountPaid: double.tryParse(paidCtrl.text.trim()) ?? b.amountPaid,
                notes: notesCtrl.text.trim(),
              ));
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context, TripProvider prov) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('⚠️ حذف نهائي'),
        content: const Text('سيتم حذف الرحلة وكل حجوزاتها نهائياً ولن تعود.\nهل أنت متأكد؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.absent),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف نهائي', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (ok == true && context.mounted) {
      await prov.deleteTrip(tripId);
      Navigator.pop(context);
    }
  }

  Future<void> _confirmDeleteBooking(BuildContext context, String bookingId,
      String name, TripProvider prov) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('حذف حجز $name؟'),
        content: const Text('الحذف نهائي ولن يعود.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.absent),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (ok == true) await prov.deleteBooking(bookingId);
  }
}
