import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/trip_provider.dart';
import '../../providers/auth_provider.dart';
import '../../models/trip_model.dart';
import '../../core/utils/date_helper.dart';

class AddEditTripScreen extends StatefulWidget {
  final TripModel? trip;
  const AddEditTripScreen({super.key, this.trip});
  bool get isEditing => trip != null;

  @override
  State<AddEditTripScreen> createState() => _AddEditTripScreenState();
}

class _AddEditTripScreenState extends State<AddEditTripScreen> {
  final _formKey    = GlobalKey<FormState>();
  late final _titleCtrl = TextEditingController(text: widget.trip?.title ?? '');
  late final _descCtrl  = TextEditingController(text: widget.trip?.description ?? '');
  late final _priceCtrl = TextEditingController(
      text: widget.trip?.price.toStringAsFixed(0) ?? '');
  DateTime _selectedDate = widget.trip != null
      ? DateHelper.fromKey(widget.trip!.dateKey)
      : DateTime.now().add(const Duration(days: 7));
  bool _isSaving = false;

  @override
  void dispose() {
    _titleCtrl.dispose(); _descCtrl.dispose(); _priceCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final p = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
      locale: const Locale('ar'),
    );
    if (p != null) setState(() => _selectedDate = p);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);
    final prov = context.read<TripProvider>();
    final auth = context.read<AuthProvider>();
    if (widget.isEditing) {
      await prov.updateTrip(widget.trip!.copyWith(
        title: _titleCtrl.text.trim(),
        description: _descCtrl.text.trim(),
        dateKey: DateHelper.dateKey(_selectedDate),
        price: double.tryParse(_priceCtrl.text.trim()) ?? 0,
      ));
    } else {
      await prov.addTrip(
        title: _titleCtrl.text.trim(),
        description: _descCtrl.text.trim(),
        dateKey: DateHelper.dateKey(_selectedDate),
        price: double.tryParse(_priceCtrl.text.trim()) ?? 0,
        createdBy: auth.currentUser?.name ?? '',
      );
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.isEditing ? 'تعديل الرحلة' : 'إضافة رحلة جديدة')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _titleCtrl,
                decoration: const InputDecoration(labelText: 'اسم الرحلة *'),
                validator: (v) => v?.trim().isEmpty == true ? 'مطلوب' : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _descCtrl,
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'التفاصيل (اختياري)'),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _priceCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'السعر بالجنيه *', suffixText: 'ج'),
                validator: (v) => (double.tryParse(v ?? '') == null) ? 'أدخل رقماً صحيحاً' : null,
              ),
              const SizedBox(height: 14),
              InkWell(
                onTap: _pickDate,
                child: InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'تاريخ الرحلة',
                    suffixIcon: Icon(Icons.calendar_today_rounded),
                  ),
                  child: Text(DateHelper.displayDateWithDay(_selectedDate)),
                ),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isSaving ? null : _submit,
                  child: _isSaving
                      ? const SizedBox(height: 22, width: 22,
                          child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                      : Text(widget.isEditing ? 'حفظ التعديلات' : 'إضافة الرحلة'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
