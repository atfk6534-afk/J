import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/assignment_provider.dart';
import '../../providers/student_provider.dart';
import '../../providers/auth_provider.dart';
import '../../models/assignment_model.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/date_helper.dart';

class AssignmentsScreen extends StatefulWidget {
  const AssignmentsScreen({super.key});
  @override
  State<AssignmentsScreen> createState() => _AssignmentsScreenState();
}

class _AssignmentsScreenState extends State<AssignmentsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs = TabController(length: 2, vsync: this);

  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final assignProv = context.watch<AssignmentProvider>();
    final upcoming   = assignProv.upcoming;
    final all        = assignProv.all;
    final past       = all.where((a) {
      final today = DateHelper.dateKey(DateTime.now());
      return a.dateKey < today;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('توزيع الكلمة واللحن'),
        bottom: TabBar(
          controller: _tabs,
          tabs: const [Tab(text: 'القادمة'), Tab(text: 'السابقة')],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_rounded),
            onPressed: () => _showAddDialog(context),
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          _AssignmentList(items: upcoming, onDelete: _confirmDelete, onRemind: _sendReminder),
          _AssignmentList(items: past,     onDelete: _confirmDelete, onRemind: _sendReminder, isPast: true),
        ],
      ),
    );
  }

  Future<void> _showAddDialog(BuildContext context, {AssignmentModel? editing}) async {
    final students   = context.read<StudentProvider>().allStudents;
    final auth       = context.read<AuthProvider>();
    final assignProv = context.read<AssignmentProvider>();

    final nameCtrl   = TextEditingController(text: editing?.assignedTo ?? '');
    final phoneCtrl  = TextEditingController(text: editing?.assignedToPhone ?? '');
    final notesCtrl  = TextEditingController(text: editing?.notes ?? '');
    String type      = editing?.type ?? 'كلمة';
    int    notifHrs  = editing?.notifyBeforeHours ?? 24;
    DateTime date    = editing != null
        ? DateHelper.fromKey(editing.dateKey)
        : DateTime.now().add(const Duration(days: 7));

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) => Padding(
          padding: EdgeInsets.only(
            left: 16, right: 16, top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(editing == null ? 'إضافة توزيع جديد' : 'تعديل التوزيع',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),

                // نوع التوزيع
                Row(
                  children: ['كلمة', 'لحن'].map((t) => Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8),
                      child: ChoiceChip(
                        label: Text(t),
                        selected: type == t,
                        onSelected: (_) => setSt(() => type = t),
                      ),
                    ),
                  )).toList(),
                ),
                const SizedBox(height: 12),

                // التاريخ
                InkWell(
                  onTap: () async {
                    final p = await showDatePicker(
                      context: ctx, initialDate: date,
                      firstDate: DateTime.now().subtract(const Duration(days: 30)),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                      locale: const Locale('ar'),
                    );
                    if (p != null) setSt(() => date = p);
                  },
                  child: InputDecorator(
                    decoration: const InputDecoration(
                        labelText: 'تاريخ الحصة',
                        suffixIcon: Icon(Icons.calendar_today_rounded)),
                    child: Text(DateHelper.displayDateWithDay(date)),
                  ),
                ),
                const SizedBox(height: 12),

                // اختيار من الشباب أو كتابة اسم يدوياً
                DropdownButtonFormField<String>(
                  value: null,
                  hint: const Text('اختر شاباً (اختياري)'),
                  items: students.map((s) => DropdownMenuItem(
                      value: s.fullName,
                      child: Text(s.fullName))).toList(),
                  onChanged: (v) {
                    if (v != null) {
                      setSt(() => nameCtrl.text = v);
                      final s = students.firstWhere((s) => s.fullName == v);
                      phoneCtrl.text = s.phone;
                    }
                  },
                ),
                const SizedBox(height: 12),

                TextField(controller: nameCtrl,
                    decoration: const InputDecoration(labelText: 'اسم المسؤول *')),
                const SizedBox(height: 12),

                TextField(controller: phoneCtrl, keyboardType: TextInputType.phone,
                    textDirection: TextDirection.ltr,
                    decoration: const InputDecoration(labelText: 'رقم الواتساب (للتذكير)')),
                const SizedBox(height: 12),

                TextField(controller: notesCtrl,
                    decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)')),
                const SizedBox(height: 12),

                // مدة التذكير
                Row(
                  children: [
                    const Text('التذكير قبل: '),
                    const SizedBox(width: 8),
                    DropdownButton<int>(
                      value: notifHrs,
                      items: const [
                        DropdownMenuItem(value: 2,  child: Text('٢ ساعة')),
                        DropdownMenuItem(value: 6,  child: Text('٦ ساعات')),
                        DropdownMenuItem(value: 12, child: Text('١٢ ساعة')),
                        DropdownMenuItem(value: 24, child: Text('يوم واحد')),
                        DropdownMenuItem(value: 48, child: Text('يومين')),
                        DropdownMenuItem(value: 168, child: Text('أسبوع')),
                      ],
                      onChanged: (v) => setSt(() => notifHrs = v ?? 24),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      if (nameCtrl.text.trim().isEmpty) return;
                      if (editing == null) {
                        await assignProv.addAssignment(
                          dateKey: DateHelper.dateKey(date),
                          type: type,
                          assignedTo: nameCtrl.text.trim(),
                          assignedToPhone: phoneCtrl.text.trim(),
                          notifyBeforeHours: notifHrs,
                          notes: notesCtrl.text.trim(),
                          createdBy: auth.currentUser?.name ?? '',
                        );
                      } else {
                        await assignProv.updateAssignment(editing.copyWith(
                          dateKey: DateHelper.dateKey(date), type: type,
                          assignedTo: nameCtrl.text.trim(),
                          assignedToPhone: phoneCtrl.text.trim(),
                          notifyBeforeHours: notifHrs,
                          notes: notesCtrl.text.trim(),
                        ));
                      }
                      if (ctx.mounted) Navigator.pop(ctx);
                    },
                    child: Text(editing == null ? 'إضافة' : 'حفظ'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context, AssignmentModel a) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف نهائي'),
        content: Text('سيتم حذف توزيع ${a.type} ليوم '
            '${DateHelper.displayDate(DateHelper.fromKey(a.dateKey))} نهائياً.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.absent),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (ok == true && context.mounted) {
      await context.read<AssignmentProvider>().deleteAssignment(a.id);
    }
  }

  Future<void> _sendReminder(BuildContext context, AssignmentModel a) async {
    final ok = await context.read<AssignmentProvider>().sendReminder(a);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(ok ? 'تم فتح واتساب للإرسال' : 'لا يوجد رقم واتساب لهذا التوزيع'),
      ));
    }
  }
}

class _AssignmentList extends StatelessWidget {
  final List<AssignmentModel> items;
  final Future<void> Function(BuildContext, AssignmentModel) onDelete;
  final Future<void> Function(BuildContext, AssignmentModel) onRemind;
  final bool isPast;

  const _AssignmentList({
    required this.items,
    required this.onDelete,
    required this.onRemind,
    this.isPast = false,
  });

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return Center(
        child: Text(isPast ? 'لا توجد توزيعات سابقة' : 'لا توجد توزيعات قادمة'),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: items.length,
      itemBuilder: (context, i) {
        final a        = items[i];
        final isKalima = a.type == 'كلمة';
        final color    = isKalima ? AppColors.primary : AppColors.secondary;
        final date     = DateHelper.fromKey(a.dateKey);

        return Card(
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: color.withValues(alpha: 0.15),
              child: Text(a.type[0],
                  style: TextStyle(fontWeight: FontWeight.bold, color: color)),
            ),
            title: Row(
              children: [
                Text(a.assignedTo, style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(a.type, style: TextStyle(fontSize: 11, color: color)),
                ),
              ],
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(DateHelper.displayDateWithDay(date)),
                if (a.notes.isNotEmpty)
                  Text(a.notes, style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (a.assignedToPhone.isNotEmpty)
                  IconButton(
                    icon: const Icon(Icons.send_rounded, size: 20, color: AppColors.present),
                    tooltip: 'إرسال تذكير واتساب',
                    onPressed: () => onRemind(context, a),
                  ),
                IconButton(
                  icon: const Icon(Icons.delete_forever_rounded, size: 20, color: AppColors.absent),
                  onPressed: () => onDelete(context, a),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
