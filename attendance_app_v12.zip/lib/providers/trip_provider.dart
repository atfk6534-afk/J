import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/trip_model.dart';
import '../models/trip_booking_model.dart';
import '../services/local_db_service.dart';
import '../services/sync_service.dart';
import '../core/utils/date_helper.dart';

class TripProvider extends ChangeNotifier {
  final LocalDbService _local;
  final SyncService    _sync;
  static const _uuid  = Uuid();

  TripProvider(this._local, this._sync) {
    _sync.onDataChanged.listen((_) => notifyListeners());
  }

  List<TripModel> get allTrips => _local.getAllTrips();

  List<TripBooking> bookingsFor(String tripId) =>
      _local.getBookingsForTrip(tripId);

  List<TripBooking> bookingsForStudent(String studentId) =>
      _local.getBookingsForStudent(studentId);

  double totalPaidFor(String tripId) =>
      _local.getBookingsForTrip(tripId).fold(0, (s, b) => s + b.amountPaid);

  // ── إضافة رحلة ────────────────────────────────────────────────────────────
  Future<void> addTrip({
    required String title,
    required String dateKey,
    required double price,
    String description = '',
    String createdBy = '',
  }) async {
    final now = DateTime.now();
    final trip = TripModel(
      id: _uuid.v4(), title: title, description: description,
      dateKey: dateKey, price: price, createdBy: createdBy,
      createdAt: now, updatedAt: now,
    );
    await _local.saveTrip(trip);
    notifyListeners();
    _sync.syncNow();
  }

  Future<void> updateTrip(TripModel trip) async {
    await _local.saveTrip(trip.copyWith(updatedAt: DateTime.now(), needsSync: true));
    notifyListeners();
    _sync.syncNow();
  }

  /// حذف نهائي — لا يعود
  Future<void> deleteTrip(String tripId) async {
    // احذف الحجوزات المرتبطة أولاً
    for (final b in _local.getBookingsForTrip(tripId)) {
      await _local.hardDeleteBooking(b.id);
    }
    await _local.hardDeleteTrip(tripId);
    notifyListeners();
    _sync.syncNow();
  }

  // ── الحجوزات ───────────────────────────────────────────────────────────────
  Future<void> addBooking({
    required String tripId,
    required String studentId,
    required double amountPaid,
    String notes = '',
    String createdBy = '',
  }) async {
    final now = DateTime.now();
    final booking = TripBooking(
      id: _uuid.v4(), tripId: tripId, studentId: studentId,
      amountPaid: amountPaid, notes: notes, createdBy: createdBy,
      createdAt: now, updatedAt: now,
    );
    await _local.saveBooking(booking);
    notifyListeners();
    _sync.syncNow();
  }

  Future<void> updateBooking(TripBooking booking) async {
    await _local.saveBooking(
        booking.copyWith(updatedAt: DateTime.now(), needsSync: true));
    notifyListeners();
    _sync.syncNow();
  }

  /// حذف حجز نهائي — لا يعود
  Future<void> deleteBooking(String bookingId) async {
    await _local.hardDeleteBooking(bookingId);
    notifyListeners();
    _sync.syncNow();
  }
}
