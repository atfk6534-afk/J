import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/assignment_model.dart';
import '../services/local_db_service.dart';
import '../services/sync_service.dart';
import '../services/notification_service.dart';

class AssignmentProvider extends ChangeNotifier {
  final LocalDbService      _local;
  final SyncService         _sync;
  final NotificationService _notif;
  static const _uuid = Uuid();

  AssignmentProvider(this._local, this._sync, this._notif) {
    _sync.onDataChanged.listen((_) => notifyListeners());
    // فحص الإشعارات عند بدء التطبيق
    _notif.checkPendingNotifications(_local);
  }

  List<AssignmentModel> get all       => _local.getAllAssignments();
  List<AssignmentModel> get upcoming  => _local.getUpcomingAssignments();

  Future<void> addAssignment({
    required String dateKey,
    required String type,
    required String assignedTo,
    String assignedToPhone = '',
    int notifyBeforeHours  = 24,
    String notes           = '',
    String createdBy       = '',
  }) async {
    final now = DateTime.now();
    final a   = AssignmentModel(
      id: _uuid.v4(), dateKey: dateKey, type: type,
      assignedTo: assignedTo, assignedToPhone: assignedToPhone,
      notifyBeforeHours: notifyBeforeHours, notes: notes,
      createdBy: createdBy, createdAt: now, updatedAt: now,
    );
    await _local.saveAssignment(a);
    notifyListeners();
    _sync.syncNow();
  }

  Future<void> updateAssignment(AssignmentModel a) async {
    await _local.saveAssignment(
        a.copyWith(updatedAt: DateTime.now(), notificationSent: false, needsSync: true));
    notifyListeners();
    _sync.syncNow();
  }

  /// حذف نهائي — لا يعود
  Future<void> deleteAssignment(String id) async {
    await _notif.cancelAll();
    await _local.hardDeleteAssignment(id);
    notifyListeners();
    _sync.syncNow();
  }

  /// إرسال تذكير واتساب يدوي
  Future<bool> sendReminder(AssignmentModel a) =>
      _notif.sendWhatsappReminder(a);

  /// فحص الإشعارات يدوياً
  Future<void> checkNotifications() =>
      _notif.checkPendingNotifications(_local);
}
