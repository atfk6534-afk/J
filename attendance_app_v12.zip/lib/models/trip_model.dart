import 'package:hive/hive.dart';

class TripModel {
  final String id;
  String title;
  String description;
  String dateKey;       // yyyy-MM-dd
  double price;
  String createdBy;
  final DateTime createdAt;
  DateTime updatedAt;
  bool isDeleted;
  bool permanentlyDeleted;
  bool needsSync;

  TripModel({
    required this.id,
    required this.title,
    this.description = '',
    required this.dateKey,
    required this.price,
    this.createdBy = '',
    required this.createdAt,
    required this.updatedAt,
    this.isDeleted = false,
    this.permanentlyDeleted = false,
    this.needsSync = true,
  });

  TripModel copyWith({
    String? title, String? description, String? dateKey,
    double? price, String? createdBy, DateTime? updatedAt,
    bool? isDeleted, bool? permanentlyDeleted, bool? needsSync,
  }) => TripModel(
    id: id, title: title ?? this.title,
    description: description ?? this.description,
    dateKey: dateKey ?? this.dateKey,
    price: price ?? this.price,
    createdBy: createdBy ?? this.createdBy,
    createdAt: createdAt, updatedAt: updatedAt ?? this.updatedAt,
    isDeleted: isDeleted ?? this.isDeleted,
    permanentlyDeleted: permanentlyDeleted ?? this.permanentlyDeleted,
    needsSync: needsSync ?? this.needsSync,
  );

  Map<String, dynamic> toMap() => {
    'id': id, 'title': title, 'description': description,
    'dateKey': dateKey, 'price': price, 'createdBy': createdBy,
    'createdAt': createdAt.millisecondsSinceEpoch,
    'updatedAt': updatedAt.millisecondsSinceEpoch,
    'isDeleted': isDeleted, 'permanentlyDeleted': permanentlyDeleted,
  };

  factory TripModel.fromMap(Map<String, dynamic> m) => TripModel(
    id: m['id'], title: m['title'], description: m['description'] ?? '',
    dateKey: m['dateKey'], price: (m['price'] as num).toDouble(),
    createdBy: m['createdBy'] ?? '',
    createdAt: DateTime.fromMillisecondsSinceEpoch(m['createdAt']),
    updatedAt: DateTime.fromMillisecondsSinceEpoch(m['updatedAt']),
    isDeleted: m['isDeleted'] ?? false,
    permanentlyDeleted: m['permanentlyDeleted'] ?? false,
    needsSync: false,
  );
}

class TripModelAdapter extends TypeAdapter<TripModel> {
  @override final int typeId = 4;
  @override TripModel read(BinaryReader r) {
    final m = r.readMap();
    return TripModel(
      id: m['id'], title: m['title'], description: m['description'] ?? '',
      dateKey: m['dateKey'], price: (m['price'] as num).toDouble(),
      createdBy: m['createdBy'] ?? '',
      createdAt: DateTime.fromMillisecondsSinceEpoch(m['createdAt']),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(m['updatedAt']),
      isDeleted: m['isDeleted'] ?? false,
      permanentlyDeleted: m['permanentlyDeleted'] ?? false,
      needsSync: m['needsSync'] ?? false,
    );
  }
  @override void write(BinaryWriter w, TripModel o) => w.writeMap({
    'id': o.id, 'title': o.title, 'description': o.description,
    'dateKey': o.dateKey, 'price': o.price, 'createdBy': o.createdBy,
    'createdAt': o.createdAt.millisecondsSinceEpoch,
    'updatedAt': o.updatedAt.millisecondsSinceEpoch,
    'isDeleted': o.isDeleted, 'permanentlyDeleted': o.permanentlyDeleted,
    'needsSync': o.needsSync,
  });
}
