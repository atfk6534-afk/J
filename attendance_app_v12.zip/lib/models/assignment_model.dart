import 'package:hive/hive.dart';

/// توزيع الكلمة أو اللحن — يُسند لخادم أو شاب في تاريخ معين
class AssignmentModel {
  final String id;
  String dateKey;          // yyyy-MM-dd (يوم الحصة)
  String type;             // 'كلمة' أو 'لحن'
  String assignedTo;       // اسم الخادم أو الشاب
  String assignedToPhone;  // للإشعار عبر واتساب
  int notifyBeforeHours;   // كم ساعة قبل الحصة يُرسل التذكير
  bool notificationSent;
  String notes;
  String createdBy;
  final DateTime createdAt;
  DateTime updatedAt;
  bool isDeleted;
  bool permanentlyDeleted;
  bool needsSync;

  AssignmentModel({
    required this.id,
    required this.dateKey,
    required this.type,
    required this.assignedTo,
    this.assignedToPhone = '',
    this.notifyBeforeHours = 24,
    this.notificationSent = false,
    this.notes = '',
    this.createdBy = '',
    required this.createdAt,
    required this.updatedAt,
    this.isDeleted = false,
    this.permanentlyDeleted = false,
    this.needsSync = true,
  });

  AssignmentModel copyWith({
    String? dateKey, String? type, String? assignedTo,
    String? assignedToPhone, int? notifyBeforeHours,
    bool? notificationSent, String? notes, String? createdBy,
    DateTime? updatedAt, bool? isDeleted,
    bool? permanentlyDeleted, bool? needsSync,
  }) => AssignmentModel(
    id: id,
    dateKey: dateKey ?? this.dateKey,
    type: type ?? this.type,
    assignedTo: assignedTo ?? this.assignedTo,
    assignedToPhone: assignedToPhone ?? this.assignedToPhone,
    notifyBeforeHours: notifyBeforeHours ?? this.notifyBeforeHours,
    notificationSent: notificationSent ?? this.notificationSent,
    notes: notes ?? this.notes,
    createdBy: createdBy ?? this.createdBy,
    createdAt: createdAt, updatedAt: updatedAt ?? this.updatedAt,
    isDeleted: isDeleted ?? this.isDeleted,
    permanentlyDeleted: permanentlyDeleted ?? this.permanentlyDeleted,
    needsSync: needsSync ?? this.needsSync,
  );

  Map<String, dynamic> toMap() => {
    'id': id, 'dateKey': dateKey, 'type': type,
    'assignedTo': assignedTo, 'assignedToPhone': assignedToPhone,
    'notifyBeforeHours': notifyBeforeHours,
    'notificationSent': notificationSent,
    'notes': notes, 'createdBy': createdBy,
    'createdAt': createdAt.millisecondsSinceEpoch,
    'updatedAt': updatedAt.millisecondsSinceEpoch,
    'isDeleted': isDeleted, 'permanentlyDeleted': permanentlyDeleted,
  };

  factory AssignmentModel.fromMap(Map<String, dynamic> m) => AssignmentModel(
    id: m['id'], dateKey: m['dateKey'], type: m['type'],
    assignedTo: m['assignedTo'], assignedToPhone: m['assignedToPhone'] ?? '',
    notifyBeforeHours: m['notifyBeforeHours'] ?? 24,
    notificationSent: m['notificationSent'] ?? false,
    notes: m['notes'] ?? '', createdBy: m['createdBy'] ?? '',
    createdAt: DateTime.fromMillisecondsSinceEpoch(m['createdAt']),
    updatedAt: DateTime.fromMillisecondsSinceEpoch(m['updatedAt']),
    isDeleted: m['isDeleted'] ?? false,
    permanentlyDeleted: m['permanentlyDeleted'] ?? false,
    needsSync: false,
  );
}

class AssignmentModelAdapter extends TypeAdapter<AssignmentModel> {
  @override final int typeId = 6;
  @override AssignmentModel read(BinaryReader r) {
    final m = r.readMap();
    return AssignmentModel(
      id: m['id'], dateKey: m['dateKey'], type: m['type'],
      assignedTo: m['assignedTo'], assignedToPhone: m['assignedToPhone'] ?? '',
      notifyBeforeHours: m['notifyBeforeHours'] ?? 24,
      notificationSent: m['notificationSent'] ?? false,
      notes: m['notes'] ?? '', createdBy: m['createdBy'] ?? '',
      createdAt: DateTime.fromMillisecondsSinceEpoch(m['createdAt']),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(m['updatedAt']),
      isDeleted: m['isDeleted'] ?? false,
      permanentlyDeleted: m['permanentlyDeleted'] ?? false,
      needsSync: m['needsSync'] ?? false,
    );
  }
  @override void write(BinaryWriter w, AssignmentModel o) => w.writeMap({
    'id': o.id, 'dateKey': o.dateKey, 'type': o.type,
    'assignedTo': o.assignedTo, 'assignedToPhone': o.assignedToPhone,
    'notifyBeforeHours': o.notifyBeforeHours,
    'notificationSent': o.notificationSent,
    'notes': o.notes, 'createdBy': o.createdBy,
    'createdAt': o.createdAt.millisecondsSinceEpoch,
    'updatedAt': o.updatedAt.millisecondsSinceEpoch,
    'isDeleted': o.isDeleted, 'permanentlyDeleted': o.permanentlyDeleted,
    'needsSync': o.needsSync,
  });
}
