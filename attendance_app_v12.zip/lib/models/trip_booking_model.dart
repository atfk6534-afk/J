import 'package:hive/hive.dart';

class TripBooking {
  final String id;
  final String tripId;
  final String studentId;
  double amountPaid;
  String notes;
  String createdBy;
  final DateTime createdAt;
  DateTime updatedAt;
  bool isDeleted;
  bool permanentlyDeleted;
  bool needsSync;

  TripBooking({
    required this.id,
    required this.tripId,
    required this.studentId,
    this.amountPaid = 0,
    this.notes = '',
    this.createdBy = '',
    required this.createdAt,
    required this.updatedAt,
    this.isDeleted = false,
    this.permanentlyDeleted = false,
    this.needsSync = true,
  });

  TripBooking copyWith({
    double? amountPaid, String? notes, String? createdBy,
    DateTime? updatedAt, bool? isDeleted,
    bool? permanentlyDeleted, bool? needsSync,
  }) => TripBooking(
    id: id, tripId: tripId, studentId: studentId,
    amountPaid: amountPaid ?? this.amountPaid,
    notes: notes ?? this.notes, createdBy: createdBy ?? this.createdBy,
    createdAt: createdAt, updatedAt: updatedAt ?? this.updatedAt,
    isDeleted: isDeleted ?? this.isDeleted,
    permanentlyDeleted: permanentlyDeleted ?? this.permanentlyDeleted,
    needsSync: needsSync ?? this.needsSync,
  );

  Map<String, dynamic> toMap() => {
    'id': id, 'tripId': tripId, 'studentId': studentId,
    'amountPaid': amountPaid, 'notes': notes, 'createdBy': createdBy,
    'createdAt': createdAt.millisecondsSinceEpoch,
    'updatedAt': updatedAt.millisecondsSinceEpoch,
    'isDeleted': isDeleted, 'permanentlyDeleted': permanentlyDeleted,
  };

  factory TripBooking.fromMap(Map<String, dynamic> m) => TripBooking(
    id: m['id'], tripId: m['tripId'], studentId: m['studentId'],
    amountPaid: (m['amountPaid'] as num?)?.toDouble() ?? 0,
    notes: m['notes'] ?? '', createdBy: m['createdBy'] ?? '',
    createdAt: DateTime.fromMillisecondsSinceEpoch(m['createdAt']),
    updatedAt: DateTime.fromMillisecondsSinceEpoch(m['updatedAt']),
    isDeleted: m['isDeleted'] ?? false,
    permanentlyDeleted: m['permanentlyDeleted'] ?? false,
    needsSync: false,
  );
}

class TripBookingAdapter extends TypeAdapter<TripBooking> {
  @override final int typeId = 5;
  @override TripBooking read(BinaryReader r) {
    final m = r.readMap();
    return TripBooking(
      id: m['id'], tripId: m['tripId'], studentId: m['studentId'],
      amountPaid: (m['amountPaid'] as num?)?.toDouble() ?? 0,
      notes: m['notes'] ?? '', createdBy: m['createdBy'] ?? '',
      createdAt: DateTime.fromMillisecondsSinceEpoch(m['createdAt']),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(m['updatedAt']),
      isDeleted: m['isDeleted'] ?? false,
      permanentlyDeleted: m['permanentlyDeleted'] ?? false,
      needsSync: m['needsSync'] ?? false,
    );
  }
  @override void write(BinaryWriter w, TripBooking o) => w.writeMap({
    'id': o.id, 'tripId': o.tripId, 'studentId': o.studentId,
    'amountPaid': o.amountPaid, 'notes': o.notes, 'createdBy': o.createdBy,
    'createdAt': o.createdAt.millisecondsSinceEpoch,
    'updatedAt': o.updatedAt.millisecondsSinceEpoch,
    'isDeleted': o.isDeleted, 'permanentlyDeleted': o.permanentlyDeleted,
    'needsSync': o.needsSync,
  });
}
